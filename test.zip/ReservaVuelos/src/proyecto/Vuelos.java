package proyecto;

public class Vuelos {
	String origen;
	String destino;
	int fecha;
	int hora;
	// cantidad de asientos
	// asientosDisponibles

	public Vuelos(String origen, String destino, int fecha, int hora) {
		super();
		this.origen = origen;
		this.destino = destino;
		this.fecha = fecha;
		this.hora = hora;
	}

	public String getOrigen() {
		return origen;
	}

	public void setOrigen(String origen) {
		this.origen = origen;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public int getFecha() {
		return fecha;
	}

	public void setFecha(int fecha) {
		this.fecha = fecha;
	}

	public int getHora() {
		return hora;
	}

	public void setHora(int hora) {
		this.hora = hora;
	}

}
