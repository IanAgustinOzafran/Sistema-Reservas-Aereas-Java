package proyecto;

public class Pasajeros {
	String nombre;
	String apellido;
	String pasaporte;

	public Pasajeros(String nombre, String apellido, String pasaporte) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.pasaporte = pasaporte;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getPasaporte() {
		return pasaporte;
	}

	public void setPasaporte(String pasaporte) {
		this.pasaporte = pasaporte;
	}

}
