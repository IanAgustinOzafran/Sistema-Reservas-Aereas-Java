package proyecto;

public class Reservas {
	int numReserva;
	//

}
